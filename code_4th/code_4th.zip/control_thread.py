import threading
from .UIPanel import UIPanel
import time
import sys, traceback



class MainControl(UIPanel):
    def __init__(self,parent,left):
        UIPanel.__init__(self,parent = parent , left = left)
        
        self.STOP_FLAG_read = False
        self.lock = threading.Lock()
        

    def read_th(self):
        while not self.STOP_FLAG_read:
            try:
                self.left.set_data(self.con.get_data())
                self.textValue.SetLabel(str('%.2f' %self.left.get_volt_max()))
                self.textfrequncy.SetLabel(self.left.get_fmax())
                self.left.animate()
            except Exception as e:
                print("read thread error")
                print(e)
                if self.STOP_FLAG_read == True:
                    break
        return 




    def OnStartClick(self,event):
        val = self.togglebuttonStart.GetValue()
        if(val == True):
            try:
                # click start logic
                self.STOP_FLAG_read = False
                self.con.connect()
                self.con.read_start()
                
            except:
                self.togglebuttonStart.SetLabel("start")
                self.togglebuttonStart.SetValue(False) 
            
            self.togglebuttonStart.SetLabel("stop")
    
            try:    
                self.con.write_start()
                self.read_thread = threading.Thread(target = self.read_th,daemon= True)
                self.read_thread.start()

                # self.read_thread.start()    
            except Exception as e:
                print("start click error",e)

        else:
            try:
                # click stop logic
                self.lock.acquire()
                self.STOP_FLAG_read = True
                self.lock.release()
                
                # thread join logic
                print("in")
                self.con.read_end()
                print("send_read_end")
                self.con.ser.cancel_read()
                print("read_close()")
                self.read_thread.join()
                print("out")
                self.con.write_stop()
                
                self.con.disconnect()

                self.togglebuttonStart.SetLabel("Start")
                self.togglebuttonStart.SetValue(False) 
                print("end succes")
            except Exception as e:
                print("stop click error", e)
                self.togglebuttonStart.SetLabel("Stop")
                self.togglebuttonStart.SetValue(True)
